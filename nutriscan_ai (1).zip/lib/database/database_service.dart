import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  static late Database db;

  static Future<void> init() async {
    final databasePath = await getDatabasesPath();

    final path = join(
      databasePath,
      'nutriscan.db',
    );

    db = await openDatabase(
      path,
      version: 1,
      onCreate: (
        db,
        version,
      ) async {
        await db.execute('''

CREATE TABLE users(

id INTEGER PRIMARY KEY AUTOINCREMENT,

name TEXT,

email TEXT UNIQUE,

password TEXT,

premium INTEGER,

freeScans INTEGER

)

''');
      },
    );
    await createProfileTable();
  }

  static Future<bool> checkEmail(String email) async {
    final result = await db.query(
      'users',
      where: 'email=?',
      whereArgs: [
        email,
      ],
    );

    return result.isNotEmpty;
  }

  static Future<int> createUser({
    required String name,
    required String email,
    required String password,
  }) async {
    return await db.insert(
      'users',
      {
        'name': name,
        'email': email,
        'password': password,
        'premium': 0,
        'freeScans': 3,
      },
    );
  }

  static Future<Map<String, dynamic>?> login(
      String email, String password) async {
    final result = await db.query(
      'users',
      where: 'email=? AND password=?',
      whereArgs: [
        email,
        password,
      ],
    );

    if (result.isNotEmpty) {
      return result.first;
    }

    return null;
  }

  static Future<List<Map<String, dynamic>>> getUsers() async {
    return await db.query(
      'users',
    );
  }

  static Future<void> deleteUser(int id) async {
    await db.delete(
      'users',
      where: 'id=?',
      whereArgs: [
        id,
      ],
    );
  }

  static Future<void> updateProfile({
    required int id,
    required String name,
    required String email,
  }) async {
    await db.update(
      'users',
      {
        'name': name,
        'email': email,
      },
      where: 'id=?',
      whereArgs: [
        id,
      ],
    );
  }

  static Future<void> updateFreeScan(int id, int count) async {
    await db.update(
      'users',
      {
        'freeScans': count,
      },
      where: 'id=?',
      whereArgs: [
        id,
      ],
    );
  }

  //profile_Screen
  static Future<void> createProfileTable() async {
    await db.execute('''

CREATE TABLE IF NOT EXISTS profile(

id INTEGER PRIMARY KEY,

name TEXT,

email TEXT,

dob TEXT,

age TEXT,

image TEXT

)

''');
  }

  static Future<void> saveProfile({
    required String name,
    required String email,
    required String dob,
    required String age,
    required String image,
  }) async {
    await db.insert(
      'profile',
      {
        'id': 1,
        'name': name,
        'email': email,
        'dob': dob,
        'age': age,
        'image': image,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  static Future<Map<String, dynamic>?> getProfile() async {
    final data = await db.query(
      'profile',
    );

    if (data.isNotEmpty) {
      return data.first;
    }

    return null;
  }
}
