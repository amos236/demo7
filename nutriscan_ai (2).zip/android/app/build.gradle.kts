plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

android {

    namespace = "com.example.nutriscan_ai"

    compileSdk = 36

    ndkVersion = "28.2.13676358"

    defaultConfig {

        applicationId = "com.example.nutriscan_ai"

        minSdk = 24

        targetSdk = 36

        versionCode = 1

        versionName = "1.0"
    }
}

flutter {
    source = "../.."
}