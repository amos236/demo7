import 'package:flutter/material.dart';

import 'database/database_service.dart';

import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/home_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/food_result_screen.dart';
import 'screens/payment_screen.dart';
import 'screens/admin_login_screen.dart';
import 'screens/admin_dashboard_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await DatabaseService.init();

  runApp(
    const NutriScanAI(),
  );
}

class NutriScanAI extends StatelessWidget {
  const NutriScanAI({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NutriScan AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
      ),
      home: const SplashScreen(),
      routes: {
        '/login': (_) => const LoginScreen(),
        '/signup': (_) => const SignupScreen(),
        '/home': (_) => const HomeScreen(),
        '/profile': (_) => const ProfileScreen(),
        '/foodResult': (_) => const FoodResultScreen(),
        '/payment': (_) => const PaymentScreen(),
        '/adminLogin': (_) => const AdminLoginScreen(),
        '/adminDashboard': (_) => const AdminDashboardScreen(),
      },
    );
  }
}
